package com.amrita.jpl.cys20134.pract.basic;

public class addition {
    /**
     * The main method is the entry point of the program.
     * It establishes a connection to the server, sends a message, and closes the connection.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        int a=9;
        int b=13;
        int c=a+b;
        System.out.println(c);

    }
}
