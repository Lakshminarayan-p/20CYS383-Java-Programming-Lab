package com.amrita.jpl.cys21034.pract.pattern;

public class pattern {
    /**
     * The main method is the entry point of the program.
     * It establishes a connection to the server, sends a message, and closes the connection.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ===================================");
        }
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
    }
}